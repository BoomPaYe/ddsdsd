class Config {
  static const apiUrl = "localhost:3000";
  static const String productUrl = "api/products";
}
